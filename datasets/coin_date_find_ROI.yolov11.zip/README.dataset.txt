# coin_date_find_roi > 2025-07-08 3:53pm
https://universe.roboflow.com/levhasanworkspace-kcxq6/coin_date_find_roi

Provided by a Roboflow user
License: CC BY 4.0

