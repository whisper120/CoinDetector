# coin_date_only_roi > 2025-07-09 12:13pm
https://universe.roboflow.com/levhasanworkspace-kcxq6/coin_date_only_roi

Provided by a Roboflow user
License: CC BY 4.0

